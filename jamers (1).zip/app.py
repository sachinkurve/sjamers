from flask import Flask, jsonify, request
from flask_cors import CORS
import pymysql

app = Flask(__name__)
cors = CORS(app)

@app.route('/users', methods=['GET'])
def get_users():
    # To connect MySQL database
    conn = pymysql.connect(host='ciacloud.in', user='tjamers', password = "tjamers%TGBbgt5", db='tjamers')
        
    cur = conn.cursor(pymysql.cursors.DictCursor)
    cur.execute("select * from emps_details LIMIT 10")
    employees = cur.fetchall()
    
    print(type(employees)); #this will print tuple	

    print(employees)

     
    # To close the connection
    
    return jsonify(employees)

   #conn.close()  
    
if __name__ == "__main__":
    #app.run(debug=True);
    app.run(host="0.0.0.0", port=int("1235"), debug=True)
   